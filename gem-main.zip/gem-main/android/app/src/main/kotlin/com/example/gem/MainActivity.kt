package com.example.gem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
